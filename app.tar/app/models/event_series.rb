class EventSeries < ActiveRecord::Base
end
